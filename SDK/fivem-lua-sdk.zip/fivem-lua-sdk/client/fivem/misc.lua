-- @todo
-- @module fivem
-- @submodule misc
-- @link https://wiki.fivem.net/wiki/SetTextChatEnabled
-- @return void
function SetTextChatEnabled() end